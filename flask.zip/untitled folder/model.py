from nltk.tokenize import word_tokenize
import nltk
import numpy as np
nltk.download('punkt')
import pandas as pd
import pickle

train = pd.read_csv('train.csv')

import string
nltk.download('stopwords')
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
ps = PorterStemmer()

def nlp(text_str):
    k = word_tokenize(text_str)
    for i in range(len(k)):
        k[i] = k[i].lower()
    k = [ps.stem(i) for i in k if i not in list(string.punctuation) and i not in stopwords.words('english')]
    k = " ".join(k)
    return k

train_x = pd.concat([train['text'], pd.Series('hello disaster 6:00pm Los Angelos')])
train_x = train_x.reset_index()[0]

for i in range(len(train_x)):
    train_x[i] = nlp(train_x[i])


from sklearn.feature_extraction.text import CountVectorizer
count_vect = CountVectorizer()
x_train = count_vect.fit_transform(train_x)
x_train = x_train[:-1]
y_train = train['target']

from catboost import CatBoostClassifier
cat_boost = CatBoostClassifier(verbose=0, random_state = 123)
cat_boost.fit(x_train, y_train)

pickle.dump(cat_boost, open('model.pkl', 'wb'))


print(cat_boost.predict(x_train[-1]))

